import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Crypto {
	public static void main(String[] args) throws IOException {
		int N;
		int B;
		int i, j;
		//Citirea am realizat-o cu BufferReader fiind cea mai eficienta varianta pe care am gasit-o
		BufferedReader reader = new BufferedReader(new FileReader("crypto.in"));
		String line = reader.readLine();
		String[] nums = line.split(" ");
		N = Integer.parseInt(nums[0]);
		int[] miningRate = new int[N];
		int[] cost = new int[N];
		B = Integer.parseInt(nums[1]);
		int min = Integer.MAX_VALUE;
		i = 0;
		//pentru a retine numerele, am citit linie cu 
		//linie fisierul si am separat stringurile obtinute dupa spatii
		while ((line = reader.readLine()) != null) {
			nums = line.split(" ");
			miningRate[i] = Integer.parseInt(nums[0]);
			//calculez minim aici pentrua nu mai parcurge inca o data elementele
			if (miningRate[i] < min) {
				min = miningRate[i];
			}
			cost[i] = Integer.parseInt(nums[1]);
			i++;
		}
		int sum = 0;
		int  ok = 0;
		//repet pana cand suma costurilor depaseste bugetul
		while (sum < B) {
			//am parcurs toata lista de elemente si am incrementat fiecare 
			//element care era egal cu minim atata timp cat suma era mai mica decat bugetul
			for (i = 0; i < N; i++) {
				if (miningRate[i] == min) {
					sum += cost[i];
					if (sum > B) {
						ok = 1;
						break;
					}
					miningRate[i]++;
				}
			}
			min++;
		}
		if (ok == 0) {
			min++;
		}
		PrintWriter fileOut = new PrintWriter(new FileWriter("crypto.out"));
		fileOut.print(min - 1);
		fileOut.close();
	}
}
